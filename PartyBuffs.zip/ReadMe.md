# PartyBuffs

Shows party members buffs icons without the necesity of targetting. (Doesn't work on trust and fellow)

Uses the modified icons of FFXIView of this version: https://github.com/KenshiDRK/XiView

Commands:

//pb|partybuffs help (show a list of available commands)

//pb|partybuffs size 10 (sets the icon size to 10x10)

//pb|partybuffs size 20 (sets the icon size to 20x20)

//pb|partybuffs mode w|wlist|white|whitelist (sets whitelist mode)

//pb|partybuffs mode b|blist|black|blacklist (sets blacklist mode)

![partybuffs](http://i.imgur.com/lXZfZVo.jpg)